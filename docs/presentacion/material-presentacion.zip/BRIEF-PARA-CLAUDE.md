# Brief: armar la presentación de MediConecta — Entrega 2

## Qué necesito de vos

Armame una presentación profesional en PowerPoint para defender la Entrega 2 de un Trabajo
Práctico Integrador universitario. Abajo está todo: el contexto, los criterios con los que nos
evalúan, el contenido de cada lámina y el inventario de las imágenes que te adjunto.

Podés reordenar, fusionar o dividir láminas si te parece que queda mejor, pero **no inventes
datos**: todos los números, nombres de clase y resultados de este documento son reales y están
verificados. Si algo no está acá, no lo pongas.

**Formato de salida:** un archivo `.pptx`. Si no podés generar el binario, entregame el guion
completo lámina por lámina en un formato que pueda pegar en PowerPoint, con el texto exacto de
cada una y las notas del orador.

---

## 1. Contexto

| | |
|---|---|
| **Materia** | Desarrollo de Aplicaciones II (universitaria, nivel avanzado) |
| **Trabajo** | Trabajo Práctico Integrador, que crece entrega a entrega |
| **Instancia** | Entrega 2 de 5 |
| **Dominio** | MediConecta — sistema de salud para gestión de turnos médicos |
| **Audiencia** | El docente de la cátedra y el resto de la comisión |
| **Duración** | Defensa oral de 12 a 15 minutos, con demostración en vivo intercalada |
| **Modalidad** | La defensa es **individual sobre cualquier parte**: el docente puede preguntarle a cualquier integrante sobre cualquier componente |

### Qué pedía exactamente la Entrega 2

> "Al menos 3 componentes con patrones y seguridad declarativa."

Desglosado, según la guía de la cátedra:
- llegar a al menos 3 componentes implementados y desplegados;
- tener por lo menos uno stateful y uno stateless, correctamente justificados;
- aplicar y justificar al menos 3 patrones de diseño;
- agregar seguridad declarativa mínima.

### Cómo nos evalúan (pesos oficiales de la cátedra)

| Criterio | Peso |
|---|---|
| Diseño arquitectónico y coherencia de componentes | 25% |
| Correctitud funcional e implementación | 25% |
| Patrones e integración correctamente justificados | 20% |
| Calidad de la documentación | 15% |
| Defensa oral y comprensión individual | 15% |

**Implicancia para el diseño de la presentación:** el 45% de la nota está en *arquitectura y
justificación de patrones*, no en cuántas funcionalidades hay. La presentación tiene que
dedicarle mucho más espacio a **por qué** cada decisión que a **qué** hace el sistema. La
cátedra dice textualmente que "no alcanza con nombrar tres patrones": hay que explicar qué
problema resuelve cada uno **en este dominio** y por qué se descartaron otras alternativas.

---

## 2. El proyecto en una página

MediConecta es un sistema de gestión de turnos médicos construido sobre **Jakarta EE 10**,
empaquetado como WAR y desplegado en **WildFly 36.0.1.Final** con **JDK 17**. Sin frameworks
externos: sólo el estándar.

**Arquitectura en tres capas**, con una regla estricta: cada capa sólo conoce a la que está
inmediatamente debajo.

- `presentacion` — JAX-RS. Traduce HTTP/JSON al lenguaje del dominio. No valida reglas ni decide
  permisos.
- `negocio` — EJB. Las reglas del dominio y la autorización. No sabe que existe HTTP.
- `datos` — interfaces de repositorio con implementaciones en memoria. No conoce las reglas.

**Cuatro componentes de negocio** (la consigna pedía tres):

| Componente | Tipo | Responsabilidad |
|---|---|---|
| `GestionTurnos` | `@Stateless` | Reglas de la agenda: crear, consultar, cancelar, registrar atención |
| `GestionPacientes` | `@Stateless` | Padrón de pacientes |
| `GestionProfesionales` | `@Stateless` | Plantel médico y cálculo de disponibilidad |
| `AsistenteReservaTurno` | **`@Stateful`** | Reserva guiada en 4 pasos, recordando las elecciones del usuario |

**Cuatro patrones de diseño** (la consigna pedía tres): DAO/Repository, Facade, Strategy,
Factory.

**Seguridad declarativa en dos niveles**: autenticación BASIC declarada en `web.xml`, y
autorización por rol con `@RolesAllowed` en los componentes de negocio. Tres roles:
`RECEPCION`, `MEDICO`, `PACIENTE`.

**Verificación:** 45 de 45 casos de prueba pasan contra la aplicación desplegada.

---

## 3. Los tres mensajes que la presentación tiene que dejar clavados

Si el docente se olvida de todo lo demás, que se lleve esto:

1. **"El stateful no es una etiqueta, se ve funcionando."** Tenemos capturas del servidor
   acumulando estado entre cuatro requests HTTP distintos, y la prueba del contraste: los mismos
   pasos sin cookie de sesión fallan. La justificación es demostrable, no declarativa.

2. **"Los patrones resuelven problemas reales del dominio, no están puestos para cumplir."**
   Cada uno tiene un problema concreto que lo motivó y una alternativa que se descartó con
   argumentos.

3. **"Probamos de verdad, y encontramos cosas."** No sólo compila: está desplegado y probado con
   45 casos. Y encontramos tres defectos que sólo aparecen con la aplicación corriendo. Contarlos
   nosotros, antes de que los pregunten, demuestra rigor.

---

## 4. Estructura propuesta, lámina por lámina

Son 22 láminas para 12–15 minutos. Marco con ⏱ las que hay que pasar rápido y con ★ las que
merecen tiempo.

---

### Lámina 1 — Portada
**Título:** MediConecta — Sistema de gestión de turnos médicos
**Subtítulo:** Entrega 2 · Componentes, patrones de diseño y seguridad declarativa
**Pie:** Desarrollo de Aplicaciones II · [dejar espacio para nombres de los integrantes y fecha]

---

### Lámina 2 — El dominio ⏱
**Mensaje clave:** Qué problema resuelve el sistema.
**Contenido:** MediConecta gestiona los turnos de un centro médico: pacientes que reservan,
profesionales que atienden, y una recepción que administra la agenda. Tres actores reales con
necesidades distintas — eso es lo que después justifica los tres roles de seguridad.
**Nota del orador:** Quince segundos. No es la parte interesante.

---

### Lámina 3 — Qué pedía la entrega y qué entregamos ★
**Mensaje clave:** Cumplimos y superamos en los tres ejes.
**Contenido:** tabla comparativa

| Pedía la consigna | Entregamos |
|---|---|
| Al menos 3 componentes | **4** (3 stateless + 1 stateful) |
| Al menos 1 stateful y 1 stateless justificados | 3 stateless + 1 stateful, justificados en el código |
| Al menos 3 patrones aplicados y defendibles | **4**: DAO, Facade, Strategy, Factory |
| Seguridad declarativa | BASIC + `@RolesAllowed`, 3 roles, 4 operaciones sensibles |
| — | 45 de 45 casos de prueba pasando contra la app desplegada |

**Nota del orador:** Esta lámina fija el marco. El resto de la presentación demuestra cada fila.

---

### Lámina 4 — Stack y por qué ⏱
**Contenido:**
- Java 17 · Jakarta EE 10 · WildFly 36.0.1.Final · Maven, empaquetado WAR
- **Una sola dependencia**: `jakarta.jakartaee-api`, en scope `provided`
- Sin frameworks externos

**Por qué `provided`:** la implementación la aporta WildFly (RESTEasy, Weld, contenedor de EJB).
Empaquetarla dentro del WAR generaría clases duplicadas en el classpath y el despliegue fallaría.
El WAR pesa unos pocos kilobytes.

---

### Lámina 5 — Arquitectura en capas ★
**Imagen:** `D1-arquitectura-en-capas.png` (a pantalla completa)
**Mensaje clave:** Las flechas van siempre hacia abajo. Ninguna capa conoce a la de arriba.
**Nota del orador:** Señalar que las flechas que salen del negocio apuntan a **interfaces** de
repositorio, no a implementaciones. Eso es lo que hace posible migrar a base de datos sin tocar
el negocio.

---

### Lámina 6 — Qué hace y qué NO hace cada capa ★
**Contenido:** tabla de tres filas. La columna de la derecha es la importante.

| Capa | Su responsabilidad | Lo que NO hace, a propósito |
|---|---|---|
| Presentación | Traduce HTTP/JSON al dominio, delega y arma la respuesta | No valida reglas, no ordena resultados, **no decide quién puede hacer qué** |
| Negocio | Reglas del dominio y autorización por rol | No sabe que existe HTTP |
| Datos | Guardar y recuperar | No conoce las reglas |

**Nota del orador:** "La prueba de que la separación es real es que cada capa se puede reemplazar
sin tocar las otras dos. Ninguno de nuestros recursos REST tiene una sola anotación de seguridad."

---

### Lámina 7 — Los 6 componentes del sistema ⏱
**Imagen:** `D3-seis-componentes.png`
**Contenido:** 4 implementados, 2 planificados (Notificaciones para la Entrega 3 con mensajería;
IntegracionObrasSociales para la Entrega 4 con SOAP + REST y patrón Adapter).
**Nota del orador:** Mostrar que la arquitectura está pensada completa desde el principio, no
improvisada entrega a entrega.

---

### Lámina 8 — Los 4 componentes implementados
**Contenido:** la tabla de la sección 2 de este brief, con las operaciones principales de cada
uno. Destacar visualmente `AsistenteReservaTurno` como el stateful.

---

### Lámina 9 — Stateless vs stateful: el criterio ★
**Mensaje clave:** La diferencia es *estado de conversación*, no *estado*.
**Contenido:**

> Un componente es **stateless** cuando no conserva estado de conversación con un cliente entre
> una invocación y la siguiente.
> Es **stateful** cuando sí lo hace, porque la operación se desarrolla a lo largo de varias
> llamadas y el servidor tiene que recordar lo que *ese* cliente fue eligiendo.

**Y la objeción anticipada, en la misma lámina** (esto lo van a preguntar):

> *"Pero los turnos se guardan en un Map, ¿eso no es estado?"*
> Es **estado de aplicación** y vive en la capa de datos, igual que viviría en una base. Es
> compartido por todos los clientes y no representa la conversación de ninguno.

---

### Lámina 10 — La prueba está en los campos de la clase ★
**Mensaje clave:** La justificación se lee en el código, no es una etiqueta.
**Contenido:** dos bloques de código enfrentados.

Izquierda — `AsistenteReservaTurno`:
```java
@Stateful
@SessionScoped
public class AsistenteReservaTurno implements Serializable {
    private String documento;      // estado de conversación:
    private String especialidad;   // sobrevive entre llamadas
    private String profesional;    // y es propio de ESTE cliente
    private String fechaHora;
```

Derecha — `GestionTurnos`:
```java
@Stateless
public class GestionTurnos {
    @Inject
    private RepositorioTurnos repositorio;   // una colaboración,
                                             // no estado del cliente
```

**Nota del orador:** "Cuatro campos contra ninguno. Por eso uno puede vivir en un pool compartido
entre clientes y el otro necesita una instancia dedicada."

---

### Lámina 11 — Cómo funciona la reserva guiada
**Imagen:** `D2-secuencia-reserva.png`
**Nota del orador:** Señalar los tres momentos marcados donde el asistente **recuerda**. Ninguno
de los otros participantes guarda nada entre mensajes.

---

### Lámina 12 — El stateful, funcionando ★★
**Imágenes:** `14-stateful-paso0.png`, `16-stateful-paso2.png`, `17-stateful-paso3-listo.png`
(tres capturas en secuencia; si no entran, usar sólo la primera y la última)
**Mensaje clave:** Cada paso es un request HTTP distinto y el panel oscuro muestra lo que el
servidor recuerda.
**Contenido:** resaltar cómo el panel `GET /api/reserva/estado` va creciendo:

```
paso 0 → {"documento":"30111222", "proximoPaso":"Elegir especialidad"}
paso 1 → + "especialidad"
paso 2 → + "profesional"
paso 3 → + "fechaHora", proximoPaso: "Confirmar la reserva"
```

**Nota del orador:** "HTTP no tiene memoria. El servidor sí, y eso es lo que estamos mostrando."

---

### Lámina 13 — La prueba definitiva: con y sin cookie ★
**Imagen:** `T4-stateful-curl.png`
**Mensaje clave:** Sin la cookie de sesión, cada request es un asistente nuevo y vacío.
**Contenido destacado:**
```
CON cookie:  {"documento":"30111222","especialidad":"Clinica Medica", ...}
SIN cookie:  {"codigo":400,"error":"Primero hay que elegir un profesional."}
```
**Nota del orador:** Es la lámina que cierra cualquier duda sobre si el componente es realmente
stateful.

---

### Lámina 14 — Los 4 patrones, de un vistazo
**Imagen:** `D4-patrones.png`
**Contenido:** tabla resumen

| Patrón | Problema del dominio que resuelve |
|---|---|
| **DAO / Repository** | Poder cambiar de almacenamiento sin tocar la lógica de negocio |
| **Facade** | Reservar exige coordinar 3 componentes; esa coordinación no puede vivir en la pantalla |
| **Strategy** | La antelación exigida para cancelar cambia según la especialidad |
| **Factory** | Alguien tiene que elegir la estrategia sin que el negocio conozca las implementaciones |

---

### Lámina 15 — DAO / Repository
**Contenido:**
- **Problema:** hoy los datos están en memoria, mañana en base de datos. Si el negocio supiera que
  detrás hay un `Map`, cambiar de almacenamiento significaría tocar las reglas del dominio.
- **Solución:** el negocio inyecta la interfaz, nunca la implementación.
  ```java
  @Inject
  private RepositorioTurnos repositorio;   // no RepositorioTurnosEnMemoria
  ```
- **La prueba:** migrar a JPA es escribir tres clases nuevas. Los cuatro componentes de negocio y
  los seis recursos REST no cambian ni una línea.
- **Alternativa descartada:** que cada componente guardara sus datos en una colección propia.
  Menos código, pero rompe la separación en capas y convertiría a los componentes en stateful sin
  querer.
- **Por qué tres repositorios y no uno:** uno solo acoplaría los tres componentes entre sí.

---

### Lámina 16 — Facade
**Contenido:**
- **Problema:** reservar un turno exige, en orden: verificar el padrón (`GestionPacientes`),
  verificar el plantel y obtener la especialidad (`GestionProfesionales`), verificar la
  disponibilidad, y recién entonces crear el turno (`GestionTurnos`). Si esa coordinación viviera
  en la capa de presentación habría lógica de negocio en la pantalla, y habría que repetirla en
  cada canal nuevo: el asistente, el REST de recepción y el SOAP de la Entrega 4.
- **El detalle que conviene señalar:** la especialidad **no la manda el cliente**, la obtiene la
  fachada del profesional. Eso evita que alguien cree por HTTP un turno de Cardiología con un
  traumatólogo y se saltee, de paso, la política de cancelación estricta.
- **Qué NO es:** no es una cuarta capa. No tiene reglas propias; sólo coordina el orden.
- **Alternativa descartada:** que `GestionTurnos` llamara a los otros dos. Evita una clase, pero
  deja a los tres acoplados en círculo.

---

### Lámina 17 — Strategy + Factory ★
**Imágenes:** `08-agenda-strategy-penalidad.png` y `09-agenda-strategy-sin-penalidad.png`
**Contenido:**

| Política | Antelación | Se aplica a | Por qué |
|---|---|---|---|
| `CancelacionFlexible` | 2 h | Clínica Médica | Se reasigna en el día |
| `CancelacionEstandar` | 24 h | Resto | Caso por defecto |
| `CancelacionEstricta` | 48 h | Cardiología, Traumatología | Reservan equipamiento |

El método de negocio no menciona 2, 24 ni 48:
```java
PoliticaCancelacion politica = fabricaPoliticas.paraEspecialidad(turno.getEspecialidad());
boolean penalidad = politica.generaPenalidad(horasDeAntelacion);
```

**Y la respuesta a "¿no son lo mismo?"**, que casi seguro van a preguntar:
> **Strategy** es *qué se hace*. **Factory** es *quién elige*. Agregar una política toca sólo la
> fábrica; cambiar cómo se calcula una penalidad toca sólo la política.

**Alternativa descartada (Strategy):** guardar las horas como un número por especialidad.
Alcanzaba para hoy, pero no para una política que además quiera mirar el historial de ausencias
del paciente. Strategy encapsula la decisión completa, no un parámetro.

---

### Lámina 18 — Seguridad: dos niveles ★
**Imagen:** `D5-seguridad-dos-niveles.png`
**Contenido:**
- **Autenticación** en `web.xml`: BASIC sobre `/api/*`, con `/api/salud` público.
- **Autorización** con `@RolesAllowed` en los **componentes de negocio**, no en los recursos REST.

**El argumento central, que hay que decir textual:**
> "Sólo recepción da de alta pacientes" es una regla del **negocio**, no de HTTP. Puesta en el
> negocio, sigue vigente cuando la misma operación se exponga por SOAP en la Entrega 4 o desde un
> consumidor de mensajería en la 3. Si estuviera sólo en el recurso REST, habría que acordarse de
> repetirla en cada canal nuevo — y alcanza con olvidarse una vez.

**Y la distinción clásica:** 401 es "no sé quién sos"; 403 es "sé quién sos y no te alcanza".

---

### Lámina 19 — Seguridad: la misma pantalla, distinto rol ★★
**Imágenes:** `04-seguridad-recepcion.png` y `05-seguridad-paciente-403.png`, lado a lado
**Mensaje clave:** No cambió una línea de código ni se reinició nada. Cambió quién soy.
**Contenido:** además, la matriz de permisos resumida

| Operación | RECEPCION | MEDICO | PACIENTE |
|---|:---:|:---:|:---:|
| Ver la agenda completa | ✅ | ✅ | ❌ |
| Ver el padrón | ✅ | ✅ | ❌ |
| **Registrar un paciente** | ✅ | ❌ | ❌ |
| **Cancelar un turno** | ✅ | ❌ | ❌ |
| **Registrar la atención** | ❌ | ✅ | ❌ |
| Usar el asistente de reserva | ✅ | ❌ | ✅ |

**Nota del orador — esto suma mucho:** explicar que las asimetrías son deliberadas. El médico no
cancela porque cancelar puede generar una penalidad económica: es un acto administrativo. La
recepción no registra la atención porque eso es un acto médico. Los roles se pensaron desde el
dominio, no como una escalera donde uno puede todo y otro nada.

---

### Lámina 20 — Verificación ★
**Imagen:** `T5-suite.png`
**Contenido:** 45 de 45 casos pasando contra la aplicación **desplegada** (no tests unitarios
sobre mocks). Cubren: la API de los cuatro componentes, las tres políticas de cancelación, la
conversación completa del asistente y las nueve combinaciones de rol y operación.
**Nota del orador:** "No es que compila: está corriendo y probado."

---

### Lámina 21 — Tres problemas que sólo aparecieron al probarlo ★★
**Mensaje clave:** Esta es la lámina que nos diferencia. Contarla nosotros vale más que
esconderla.
**Contenido:**

| Problema | Por qué pasaba | Cómo lo resolvimos |
|---|---|---|
| **Se podían crear dos turnos simultáneos con el mismo profesional** | La fecha es texto y la regla compara textos: `"09:30"` y `"09:30:00"` son el mismo instante pero dos cadenas distintas | Un formato canónico al que el negocio reescribe toda fecha antes de comparar y guardar |
| **El paso "confirmar" del asistente devolvía 500** | `@Remove` no convive con `@SessionScoped`: al poner un `@Stateful` bajo un alcance de CDI, el ciclo de vida lo gobierna CDI (`WELD-000037`) | Quitamos `@Remove`; la instancia se destruye al terminar la sesión, más un `abandonar()` explícito |
| **Cada validación de negocio dejaba un stack trace en el log** | El contenedor de EJB trata cualquier `RuntimeException` como fallo de sistema: la envuelve, loguea y hace rollback | `@ApplicationException(rollback = false)` en las excepciones de negocio |

**Nota del orador:** "Ninguno de los tres se ve compilando. Aparecieron con la aplicación
desplegada, y por eso probamos contra el contenedor y no sólo con tests unitarios."

---

### Lámina 22 — Limitaciones conocidas y qué viene
**Contenido, en dos columnas:**

*Limitaciones que asumimos:*
- Los datos viven en memoria: se pierden al reiniciar. Las interfaces de repositorio ya están
  listas para JPA.
- BASIC sobre HTTP: Base64 es codificación, no cifrado. En producción exige HTTPS.
- Un paciente autenticado puede consultar los turnos de otro por documento: falta atar el usuario
  autenticado a su propio DNI. Está documentado como pendiente.

*Próximas entregas:*
- **Entrega 3** — mensajería asincrónica: cola punto a punto y tópico pub/sub para el componente
  Notificaciones.
- **Entrega 4** — SOAP + WSDL contra el sistema legado de obras sociales, REST contra un partner
  moderno (patrón Adapter), y transacciones declarativas. *El terreno ya está preparado: al ser
  EJB, cada método público ya corre en su propia transacción.*

**Nota del orador:** Decir la tercera limitación en voz alta. Un grupo que conoce su propio
agujero de seguridad transmite más control que uno que no lo menciona.

---

## 5. Tono y diseño

- **Sobrio y técnico.** Es una defensa universitaria de ingeniería, no un pitch comercial. Nada
  de stock photos, íconos decorativos ni animaciones.
- **Una idea por lámina.** Si una lámina necesita dos mensajes, son dos láminas.
- **Poco texto.** Frases cortas; el detalle va en las notas del orador, no en la pantalla.
- **Las capturas son las protagonistas.** Cuando hay imagen, que ocupe la lámina; el texto que la
  acompaña, máximo dos líneas.
- **Paleta:** azul institucional `#1c6ea4` (es el color de la aplicación, así que las capturas
  van a combinar), gris `#f4f6f8` de fondo, texto `#22303c`. Verde `#1b7f3b` para lo permitido /
  correcto, rojo `#b3261e` para lo prohibido / error, ámbar `#b45309` para advertencias.
- **Código:** fuente monoespaciada, fondo oscuro, resaltar sólo la línea que importa. Nunca pegar
  una clase entera: máximo 6 líneas por bloque.
- **Notas del orador:** completalas en todas las láminas. Las usamos para practicar y la defensa
  es individual sobre cualquier parte.
- **Numerar las láminas.** Facilita que el docente pregunte "volvé a la 17".

---

## 6. Imágenes adjuntas

Te adjunto 30 imágenes. Todas son **capturas reales** de la aplicación corriendo en WildFly, o
renderizados de salida real de consola — ninguna es un mockup.

### Capturas de la aplicación (`capturas/`)

| Archivo | Qué muestra |
|---|---|
| `01-prueba-de-vida.png` | `GET /api/salud` devolviendo "¡Hola desde el contenedor!" sin credenciales |
| `02-api-turnos-json.png` | Respuesta JSON cruda de la API de turnos |
| `03-api-sesion-json.png` | `GET /api/sesion`: usuario, roles y método de autenticación |
| `04-seguridad-recepcion.png` | Matriz de permisos con rol RECEPCION: todo permitido |
| `05-seguridad-paciente-403.png` | **La misma pantalla** con rol PACIENTE: dos operaciones en PROHIBIDO (403) |
| `06-seguridad-medico.png` | La misma pantalla con rol MEDICO |
| `07-agenda-recepcion.png` | Agenda de turnos, vista de recepción |
| `08-agenda-strategy-penalidad.png` | Cancelación **con** penalidad: "Política Estricta (Cardiologia): requiere avisar con 48 horas y se avisó con 22" |
| `09-agenda-strategy-sin-penalidad.png` | Cancelación **sin** penalidad, misma especialidad, más antelación |
| `10-agenda-403-medico-cancela.png` | Rol MEDICO intentando cancelar: error 403 en pantalla |
| `11-pacientes-recepcion.png` | Padrón de pacientes y formulario de alta |
| `12-pacientes-403-paciente.png` | El mismo padrón con rol PACIENTE: 403 |
| `13-profesionales-horarios-libres.png` | Plantel y cálculo de horarios libres |
| `14-stateful-paso0.png` | Asistente tras el paso 0: el panel muestra sólo el documento |
| `15-stateful-paso1.png` | Tras el paso 1: se suma la especialidad |
| `16-stateful-paso2.png` | Tras el paso 2: se suma el profesional |
| `17-stateful-paso3-listo.png` | Tras el paso 3: los cuatro datos, listo para confirmar |
| `18-stateful-confirmado.png` | Confirmado: turno creado y la conversación se cerró |
| `19-agenda-con-turno-reservado.png` | El turno recién reservado, ya en la agenda |
| `20-responsive-movil.png` | La aplicación en ancho de teléfono (412 px) |

### Diagramas de arquitectura (`diagramas/`)

| Archivo | Qué muestra |
|---|---|
| `D1-arquitectura-en-capas.png` | Las tres capas, los cuatro componentes y las dependencias |
| `D2-secuencia-reserva.png` | Diagrama de secuencia de una reserva con el asistente stateful |
| `D3-seis-componentes.png` | Los 6 componentes del sistema: 4 implementados, 2 planificados |
| `D4-patrones.png` | Cómo se combinan DAO, Facade, Strategy y Factory |
| `D5-seguridad-dos-niveles.png` | El flujo 401 / 403 entre la capa web y la de negocio |

### Salida real de consola (`consola/`)

| Archivo | Qué muestra |
|---|---|
| `T1-build-maven.png` | `mvn clean package` → BUILD SUCCESS, 35 archivos compilados |
| `T2-despliegue.png` | Log de WildFly: contexto `/mediconecta` registrado y desplegado |
| `T3-seguridad-curl.png` | 200 público / 401 sin credenciales / 403 sin rol, con curl |
| `T4-stateful-curl.png` | La conversación completa del asistente, con y sin cookie de sesión |
| `T5-suite.png` | La suite completa: 45 PASS / 0 FALLA |

---

## 7. Datos exactos, para que no se desvíen

Usá estos valores textuales; son los reales y están verificados.

- Versiones: **Java 17**, **Jakarta EE 10**, **WildFly 36.0.1.Final**, Maven, empaquetado **WAR**
- Contexto de la aplicación: `http://localhost:8080/mediconecta/`
- Prueba de vida: `GET /api/salud` → **¡Hola desde el contenedor!**
- Componentes: `GestionTurnos`, `GestionPacientes`, `GestionProfesionales` (todos `@Stateless`),
  `AsistenteReservaTurno` (`@Stateful @SessionScoped`), más `FachadaAgenda` (`@Stateless`)
- Patrones: DAO/Repository, Facade, Strategy, Factory
- Políticas de cancelación: Flexible 2 h · Estándar 24 h · Estricta 48 h
- Roles: `RECEPCION`, `MEDICO`, `PACIENTE`
- Operaciones sensibles protegidas: registrar paciente, cancelar turno, registrar atención, ver
  el padrón
- Resultado de las pruebas: **45 PASS / 0 FALLA**
- Error de CDI que encontramos: **`WELD-000037`**
- Clases de código citables: `Turno.FORMATO_FECHA_HORA`, `PoliticaCancelacion`,
  `FabricaPoliticasCancelacion`, `ManejadorAccesoDenegado`, `Roles`
